/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package todolist.apps;

import javax.swing.*;
import javax.swing.border.EmptyBorder;
import javax.swing.table.DefaultTableCellRenderer;
import javax.swing.table.TableCellRenderer;
import javax.swing.table.DefaultTableModel;
import javax.swing.DefaultComboBoxModel;
import java.awt.*;
import java.awt.event.*;
import java.awt.geom.RoundRectangle2D;
import java.io.*;
import java.util.*;
import java.util.List;
import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;

/**
 *
 * @author kelompok tothelist
 */

public class TodolistApps extends JFrame {
    private Map<String, List<ItemBelanja>> lists = new LinkedHashMap<>();
    private String currentList = "Belanja Utama";
    private final String DATA_FILE = "daftar_belanja.json";
    private final Gson gson = new GsonBuilder().setPrettyPrinting().create();

    private JComboBox<String> listCombo;
    private JLabel infoLabel;
    private JProgressBar progressBar;
    private JTextField inputBarang;
    private DefaultTableModel tableModel;
    private JTable table;

    static class ItemBelanja {
        String nama;
        boolean done;

        ItemBelanja(String nama, boolean done) {
            this.nama = nama;
            this.done = done;
        }
        
        // Default constructor untuk Gson
        ItemBelanja() {
        }
    }

    // CUSTOM ROUNDED BUTTON
    static class RoundedButton extends JButton {
        private Color bgColor;
        private Color hoverColor;
        private Color currentColor;

        public RoundedButton(String text, Color bg, Color hover) {
            super(text);
            this.bgColor = bg;
            this.hoverColor = hover;
            this.currentColor = bg;
            setFocusPainted(false);
            setContentAreaFilled(false);
            setBorderPainted(false);
            setForeground(Color.WHITE);
            setFont(new Font("Segoe UI", Font.BOLD, 14));
            setOpaque(false);

            addMouseListener(new MouseAdapter() {
                @Override
                public void mouseEntered(MouseEvent e) {
                    currentColor = hoverColor;
                    repaint();
                }

                @Override
                public void mouseExited(MouseEvent e) {
                    currentColor = bgColor;
                    repaint();
                }
            });
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(currentColor);
            g2.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 24, 24);
            super.paintComponent(g2);
            g2.dispose();
        }
    }

    // CUSTOM ROUNDED TEXT FIELD
    static class RoundedTextField extends JTextField {
        public RoundedTextField() {
            setBorder(new EmptyBorder(12, 20, 12, 20));
            setBackground(Color.WHITE);
            setOpaque(false);
            setFont(new Font("Segoe UI", Font.PLAIN, 14));
        }

        @Override
        protected void paintComponent(Graphics g) {
            Graphics2D g2 = (Graphics2D) g.create();
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
            g2.setColor(getBackground());
            g2.fillRoundRect(0, 0, getWidth(), getHeight(), 24, 24);
            g2.setColor(new Color(200, 200, 200));
            g2.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 24, 24);
            super.paintComponent(g2);
            g2.dispose();
        }
    }

    public TodolistApps() {
        loadData();
        if (lists.isEmpty()) {
            lists.put("Belanja Utama", new ArrayList<>());
        }
        if (!lists.containsKey(currentList)) {
            currentList = lists.keySet().iterator().next();
        }

        initUI();
        refreshAll();
    }

    private void initUI() {
        setTitle("Daftar Belanja");
        setSize(850, 850);                   
        setMinimumSize(new Dimension(550, 700)); 
        setResizable(true);                   
        setLocationRelativeTo(null);          
        setDefaultCloseOperation(EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setLayout(new BorderLayout());
        getContentPane().setBackground(Color.WHITE);
        
        // === MENGATUR ICON APLIKASI DI TITLE BAR ===
        
        setApplicationIcon();

        Font titleFont = new Font("Segoe UI", Font.BOLD, 28);
        Font normalFont = new Font("Segoe UI", Font.PLAIN, 14);

        JPanel topPanel = new JPanel(new GridLayout(7, 1, 10, 14));
        topPanel.setBorder(new EmptyBorder(20, 20, 10, 20));
        topPanel.setBackground(Color.WHITE);

        
        JLabel title = new JLabel(" Daftar Belanja", JLabel.CENTER);
        title.setFont(titleFont);
        title.setForeground(new Color(46, 125, 50));

        // Coba load gambar keranjang, kalau gagal pake emoji fallback
        java.net.URL iconURL = getClass().getResource("/shopping-cart.png");
        System.out.println("URL Icon: " + iconURL);  // tambahin ini buat debug

        if (iconURL != null) {
            ImageIcon originalIcon = new ImageIcon(iconURL);
            Image scaledImg = originalIcon.getImage().getScaledInstance(50, 50, Image.SCALE_SMOOTH);
            ImageIcon cartIcon = new ImageIcon(scaledImg);

            title.setIcon(cartIcon);
            title.setText(" Daftar Belanja");  // spasi depan biar rapi
            title.setHorizontalTextPosition(JLabel.RIGHT);
            title.setIconTextGap(15);
        } else {
            System.out.println("ICON GAK KETEMU! Pastikan folder assets di root src dan sudah clean+build.");
            title.setText(" Daftar Belanja");  // fallback
        }
        title.setVerticalTextPosition(JLabel.CENTER);

        topPanel.add(title);

        // JComboBox untuk pilih list
        listCombo = new JComboBox<>();
        listCombo.setFont(normalFont);             // normalFont juga sudah ada!
        listCombo.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                JLabel label = (JLabel) super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                label.setBorder(new EmptyBorder(8, 16, 8, 16));
                if (isSelected) {
                    label.setBackground(new Color(76, 175, 80));
                    label.setForeground(Color.WHITE);
                } else {
                    label.setBackground(Color.WHITE);
                    label.setForeground(Color.BLACK);
                }
                return label;
            }
        });
        listCombo.addActionListener(e -> gantiList());
        topPanel.add(listCombo);
        add(topPanel, BorderLayout.NORTH);

        RoundedButton btnBuat = new RoundedButton(" + List Baru", new Color(76, 175, 80), new Color(56, 142, 60));
        btnBuat.addActionListener(e -> buatList());
        topPanel.add(btnBuat);

        RoundedButton btnRename = new RoundedButton("️ Rename List", new Color(255, 152, 0), new Color(245, 124, 0));
        btnRename.addActionListener(e -> renameList());
        topPanel.add(btnRename);

        RoundedButton btnHapus = new RoundedButton("️ Hapus List", new Color(244, 67, 54), new Color(211, 47, 47));
        btnHapus.addActionListener(e -> hapusList());
        topPanel.add(btnHapus);

        infoLabel = new JLabel("", JLabel.CENTER);
        infoLabel.setFont(normalFont);
        infoLabel.setForeground(new Color(85, 85, 85));
        topPanel.add(infoLabel);

        progressBar = new JProgressBar(0, 100);
        progressBar.setStringPainted(true);
        progressBar.setForeground(new Color(46, 125, 50));
        progressBar.setBackground(new Color(224, 224, 224));
        progressBar.setBorderPainted(false);
        progressBar.setUI(new javax.swing.plaf.basic.BasicProgressBarUI() {
            @Override
            protected void paintDeterminate(Graphics g, JComponent c) {
                Graphics2D g2 = (Graphics2D) g.create();
                g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                int w = c.getWidth();
                int h = c.getHeight();
                g2.setColor(progressBar.getBackground());
                g2.fillRoundRect(0, 0, w, h, 20, 20);
                int progress = progressBar.getValue() * w / 100;
                g2.setColor(progressBar.getForeground());
                g2.fillRoundRect(0, 0, progress, h, 20, 20);
                if (progressBar.isStringPainted()) {
                    g2.setColor(Color.WHITE);
                    g2.setFont(new Font("Segoe UI", Font.BOLD, 12));
                    FontMetrics fm = g2.getFontMetrics();
                    String text = progressBar.getString();
                    int x = (w - fm.stringWidth(text)) / 2;
                    int y = (h + fm.getAscent()) / 2 - 2;
                    g2.drawString(text, x, y);
                }
                g2.dispose();
            }
        });
        topPanel.add(progressBar);

        add(topPanel, BorderLayout.NORTH);

        JPanel inputPanel = new JPanel(new BorderLayout(12, 0));
        inputPanel.setBorder(new EmptyBorder(0, 20, 20, 20));
        inputPanel.setBackground(Color.WHITE);

        inputBarang = new RoundedTextField();

        RoundedButton btnTambah = new RoundedButton("Tambah Barang", new Color(76, 175, 80), new Color(56, 142, 60));
        btnTambah.addActionListener(e -> tambahBarang());
        inputBarang.addActionListener(e -> tambahBarang());

        inputPanel.add(inputBarang, BorderLayout.CENTER);
        inputPanel.add(btnTambah, BorderLayout.EAST);
        add(inputPanel, BorderLayout.SOUTH);

        tableModel = new DefaultTableModel(new Object[]{"Barang", "Hapus"}, 0) {
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };

        table = new JTable(tableModel);
        table.setRowHeight(50);
        table.setShowGrid(false);
        table.setIntercellSpacing(new Dimension(0, 8));
        table.setFont(normalFont);
        table.getColumn("Hapus").setMaxWidth(90);
        table.getColumn("Hapus").setMinWidth(90);

        table.getColumn("Barang").setCellRenderer(new DefaultTableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                JLabel label = (JLabel) super.getTableCellRendererComponent(table, value, isSelected, hasFocus, row, column);
                label.setBorder(new EmptyBorder(12, 16, 12, 16));
                label.setBackground(new Color(241, 248, 233));
                label.setOpaque(true);
                label.setHorizontalAlignment(JLabel.LEFT);

                boolean done = lists.get(currentList).get(row).done;
                if (done) {
                    label.setForeground(new Color(46, 125, 50));
                    label.setFont(label.getFont().deriveFont(Font.BOLD));
                    label.setText("<html><s>" + value + "</s></html>");
                } else {
                    label.setForeground(Color.BLACK);
                    label.setFont(normalFont);
                    label.setText(value.toString());
                }
                return label;
            }
        });

        table.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int row = table.rowAtPoint(e.getPoint());
                int col = table.columnAtPoint(e.getPoint());
                
                if (row >= 0 && row < table.getRowCount() && col >= 0 && col < table.getColumnCount()) {
                    String columnName = table.getColumnName(col);
                    
                    if ("Barang".equals(columnName)) {
                        // Klik pada kolom Barang -> toggle done
                        toggleDone(row);
                    } else if ("Hapus".equals(columnName)) {
                        // Klik pada kolom Hapus -> hapus barang
                        if (currentList != null && lists.containsKey(currentList) && 
                            row >= 0 && row < lists.get(currentList).size()) {
                            hapusBarang(row);
                        }
                    }
                }
            }
        });

        // === TOMBOL HAPUS DI TIAP BARANG (MENGGUNAKAN RENDERER) ===
        // MouseListener di atas sudah menangani klik pada kolom "Hapus"
        table.getColumn("Hapus").setCellRenderer(new TableCellRenderer() {
            @Override
            public Component getTableCellRendererComponent(JTable table, Object value, boolean isSelected, boolean hasFocus, int row, int column) {
                JPanel panel = new JPanel(new BorderLayout());
                panel.setBackground(new Color(241, 248, 233));
                panel.setBorder(new EmptyBorder(5, 5, 5, 5));
                
                // Buat label yang terlihat seperti tombol (agar event mouse bisa diteruskan ke MouseListener)
                JLabel btnLabel = new JLabel("Hapus", JLabel.CENTER);
                btnLabel.setOpaque(true);
                btnLabel.setBackground(new Color(244, 67, 54));
                btnLabel.setForeground(Color.WHITE);
                btnLabel.setFont(new Font("Segoe UI", Font.BOLD, 14));
                btnLabel.setPreferredSize(new Dimension(80, 36));
                btnLabel.setBorder(new EmptyBorder(8, 0, 8, 0));
                
                // Buat border rounded dengan paintComponent
                JPanel btnPanel = new JPanel(new BorderLayout()) {
                    @Override
                    protected void paintComponent(Graphics g) {
                        Graphics2D g2 = (Graphics2D) g.create();
                        g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                        g2.setColor(new Color(244, 67, 54));
                        g2.fillRoundRect(0, 0, getWidth(), getHeight(), 24, 24);
                        super.paintComponent(g2);
                        g2.dispose();
                    }
                };
                btnPanel.setOpaque(false);
                btnPanel.add(btnLabel, BorderLayout.CENTER);
                
                panel.add(btnPanel, BorderLayout.CENTER);
                return panel;
            }
        });

        JScrollPane scroll = new JScrollPane(table);
        scroll.setBorder(null);

        JPanel tablePanel = new JPanel(new BorderLayout());
        tablePanel.setBackground(Color.WHITE);
        tablePanel.setBorder(new EmptyBorder(10, 20, 10, 20));
        tablePanel.add(scroll, BorderLayout.CENTER);
        add(tablePanel, BorderLayout.CENTER);
    }

   
    private void setApplicationIcon() {
        try {
            // Coba load icon dari resource (file di folder src/)
            // Path bisa diubah sesuai lokasi file icon Anda
            java.net.URL iconURL = getClass().getResource("/shopping-cart.png");
            
            // Alternatif: jika icon ada di folder assets
            // java.net.URL iconURL = getClass().getResource("/todolist/assets/shopping-cart.png");
            
            // Alternatif: jika ingin menggunakan file icon khusus (misalnya app-icon.ico)
            // java.net.URL iconURL = getClass().getResource("/app-icon.ico");
            
            if (iconURL != null) {
                ImageIcon icon = new ImageIcon(iconURL);
                Image image = icon.getImage();
                
                // Set icon untuk aplikasi (akan muncul di title bar dan taskbar)
                setIconImage(image);
                
                System.out.println("Icon aplikasi berhasil diatur dari: " + iconURL);
            } else {
                // Jika icon tidak ditemukan, aplikasi akan menggunakan icon default Java
                System.out.println("Icon tidak ditemukan. Menggunakan icon default Java.");
                System.out.println("Tips: Letakkan file icon di folder src/ dan ubah path di setApplicationIcon()");
            }
        } catch (Exception e) {
            // Jika terjadi error, aplikasi tetap berjalan dengan icon default
            System.out.println("Error saat mengatur icon: " + e.getMessage());
            System.out.println("Aplikasi akan menggunakan icon default Java.");
        }
    }

    private void refreshAll() { refreshCombo(); refreshTable(); refreshInfo(); }
    private void refreshCombo() {
        // Simpan currentList sebelum update
        String savedCurrentList = currentList;
        
        // Pastikan currentList masih valid setelah perubahan
        if (!lists.containsKey(savedCurrentList) && !lists.isEmpty()) {
            savedCurrentList = lists.keySet().iterator().next();
            currentList = savedCurrentList;
        }
        
        // Nonaktifkan action listener sementara untuk menghindari trigger saat update
        ActionListener[] listeners = listCombo.getActionListeners();
        for (ActionListener listener : listeners) {
            listCombo.removeActionListener(listener);
        }
        
        // Buat array list untuk model
        String[] listArray = lists.keySet().toArray(new String[0]);
        DefaultComboBoxModel<String> model = new DefaultComboBoxModel<>(listArray);
        listCombo.setModel(model);
        
        // Set selected item
        if (lists.containsKey(savedCurrentList)) {
            listCombo.setSelectedItem(savedCurrentList);
        } else if (!lists.isEmpty() && listArray.length > 0) {
            listCombo.setSelectedIndex(0);
            currentList = listArray[0];
        }
        
        // Kembalikan action listener
        for (ActionListener listener : listeners) {
            listCombo.addActionListener(listener);
        }
    }
    private void refreshTable() {
        tableModel.setRowCount(0);
        List<ItemBelanja> items = lists.get(currentList);
        for (ItemBelanja item : items) tableModel.addRow(new Object[]{item.nama, "Hapus"});
    }
    private void refreshInfo() {
        List<ItemBelanja> items = lists.get(currentList);
        int total = items.size();
        int selesai = (int) items.stream().filter(i -> i.done).count();
        infoLabel.setText("Total: " + total + " | Selesai: " + selesai);
        int persen = total == 0 ? 0 : Math.round((selesai * 100f) / total);
        progressBar.setValue(persen);
        progressBar.setString(persen + "%");
    }
    private void gantiList() { currentList = (String) listCombo.getSelectedItem(); refreshTable(); refreshInfo(); }
    private void buatList() {
        String nama = JOptionPane.showInputDialog(this, "Nama list baru:");
        if (nama == null || nama.trim().isEmpty() || lists.containsKey(nama.trim())) {
            JOptionPane.showMessageDialog(this, "Nama tidak valid atau sudah ada!"); return;
        }
        lists.put(nama.trim(), new ArrayList<>()); currentList = nama.trim(); saveData(); refreshAll();
    }
    private void renameList() {
        String namaBaru = JOptionPane.showInputDialog(this, "Nama baru:", currentList);
        if (namaBaru == null || namaBaru.trim().isEmpty() || lists.containsKey(namaBaru.trim())) {
            JOptionPane.showMessageDialog(this, "Nama tidak valid atau sudah ada!"); return;
        }
        List<ItemBelanja> items = lists.remove(currentList);
        lists.put(namaBaru.trim(), items); currentList = namaBaru.trim(); saveData(); refreshAll();
    }
    private void hapusList() {
        if (lists.size() <= 1) { JOptionPane.showMessageDialog(this, "Gak bisa hapus list terakhir!"); return; }
        int confirm = JOptionPane.showConfirmDialog(this, "Yakin hapus list '" + currentList + "'?");
        if (confirm == JOptionPane.YES_OPTION) { lists.remove(currentList); currentList = lists.keySet().iterator().next(); saveData(); refreshAll(); }
    }
    private void tambahBarang() {
        String nama = inputBarang.getText().trim();
        if (nama.isEmpty()) { JOptionPane.showMessageDialog(this, "Isi nama barang dulu!"); return; }
        lists.get(currentList).add(new ItemBelanja(nama, false)); inputBarang.setText(""); saveData(); refreshTable(); refreshInfo();
    }
    private void toggleDone(int index) {
        ItemBelanja item = lists.get(currentList).get(index); item.done = !item.done; saveData(); refreshTable(); refreshInfo();
    }
    private void hapusBarang(int index) {
        lists.get(currentList).remove(index); saveData(); refreshTable(); refreshInfo();
    }
    private void saveData() {
        try (FileWriter writer = new FileWriter(DATA_FILE)) {
            gson.toJson(lists, writer);
            writer.flush();
        } catch (IOException e) { 
            JOptionPane.showMessageDialog(this, "Gagal simpan data ke JSON: " + e.getMessage()); 
        }
    }
    private void loadData() {
        File file = new File(DATA_FILE);
        if (!file.exists()) {
            // Coba load dari file txt lama untuk migrasi
            File oldFile = new File("daftar_belanja.txt");
            if (oldFile.exists()) {
                loadDataFromTxt(oldFile);
                saveData(); // Simpan ke format JSON baru
                return;
            }
            return;
        }
        try (FileReader reader = new FileReader(file)) {
            TypeToken<Map<String, List<ItemBelanja>>> typeToken = new TypeToken<Map<String, List<ItemBelanja>>>() {};
            Map<String, List<ItemBelanja>> loaded = gson.fromJson(reader, typeToken.getType());
            if (loaded != null) {
                lists = loaded;
            }
        } catch (IOException e) { 
            JOptionPane.showMessageDialog(this, "Gagal load data dari JSON: " + e.getMessage());
            lists.clear(); 
        }
    }
    
    // Method untuk migrasi data dari format txt lama ke JSON
    private void loadDataFromTxt(File file) {
        try (BufferedReader reader = new BufferedReader(new FileReader(file))) {
            String line; String current = null;
            while ((line = reader.readLine()) != null) {
                if (line.startsWith("[LIST]")) { 
                    current = line.substring(6); 
                    lists.put(current, new ArrayList<>()); 
                }
                else if (current != null && line.contains("|")) {
                    String[] parts = line.split("\\|", 2);
                    boolean done = parts[0].equals("1");
                    lists.get(current).add(new ItemBelanja(parts[1], done));
                }
            }
        } catch (IOException e) { 
            lists.clear(); 
        }
    }

    
    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        SwingUtilities.invokeLater(() -> {
            try {
                UIManager.setLookAndFeel(UIManager.getCrossPlatformLookAndFeelClassName());
            } catch (Exception e) {
                e.printStackTrace();
            }
            new TodolistApps().setVisible(true);
        });
    }
    
}
